Hello, if your reading this then you have access to ES Mecha Sonic MK.II (obviously).
Remember to please not distribute this mod to other people outside of the OFFICIAL Sonic 3 Angel Island Revisited discord server.
You can make any mod for ES Mecha (new palletes, signpost mod, script mod, compability with the Mickey Mouse Clubhouse 3 AIR, etc), dont forget to link the original mod, wait for the mod itself to come out and/or credit me. Also dont copy and paste my scripts to your sprite change mod ( all you need is the json files for the sprites).
Any bug report, feedback or something else? @ me on the discord server.
